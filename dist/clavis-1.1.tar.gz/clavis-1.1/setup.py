from setuptools import setup

setup(
	name='clavis',
	version='1.1',
	scripts=['clavis']
)
