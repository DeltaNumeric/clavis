from setuptools import setup

setup(
	name='clavis',
	version='1.2.2',
	scripts=['clavis']
)
