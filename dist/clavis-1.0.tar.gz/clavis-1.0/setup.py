from setuptools import setup

setup(
	name='clavis',
	version='1.0',
	scripts=['clavis']
)
