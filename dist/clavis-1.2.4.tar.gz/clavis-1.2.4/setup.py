from setuptools import setup

setup(
	name='clavis',
	version='1.2.4',
	scripts=['clavis']
)
