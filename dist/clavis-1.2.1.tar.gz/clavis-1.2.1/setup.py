from setuptools import setup

setup(
	name='clavis',
	version='1.2.1',
	scripts=['clavis']
)
